import threading
import queue


class Producer(threading.Thread):
    def __init__(self, queue):
        threading.Thread.__init__(self)
        self.queue = queue

    number = 0

    def isPrime(self,number):
        i = 2
        while i <= number:
            if number % i == 0 and number != i:
                return False
            i += 1
        return True

    def run(self):
        number = 1
        while number < 100:
            number = number + 1
            if self.isPrime(number):
                self.queue.put(number)



class Consumer(threading.Thread):
    def __init__(self, queue):
        threading.Thread.__init__(self)
        self.queue = queue

    def run(self):
        new = open("Primzahlen.txt", "w") # File wird im write Modus geöffnet
        new.write("") # das File wird mit einem leeren String überschrieben, damit beim nächsten Aufruf nichts doppelt drinnen steht
        while True:
            number = self.queue.get()
            print("Primzahl: %d" % number)
            text_file = open("Primzahlen.txt", "a") # a für append, man kann mehrere Sachen an das File ranhängen
            text_file.write("Primzahl: %d \n" % number)
            text_file.close()
            self.queue.task_done()
            if number == 97:
                break



class ThreadManager(object):
    # Queue und zwei Threads werden erzeugt die über eine Queue miteinander verbunden werden(Parameter)
    def __init__(self):
        q = queue.Queue()
        self.t1 = Producer(q)
        self.t2 = Consumer(q)

    # Die zwei Threads werden über eine Queue miteinander verbunden
    def start(self):
        self.t1.start()
        self.t2.start()
        self.t1.join()
        self.t2.join()

tms = ThreadManager()
tms.start()

